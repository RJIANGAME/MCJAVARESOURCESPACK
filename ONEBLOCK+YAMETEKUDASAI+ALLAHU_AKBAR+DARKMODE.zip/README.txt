OneBlock by IJAMinecraft
Copyright (c) IJAMinecraft
https://ijaminecraft.com/en/copyright

YOU WANT TO TRANSLATE THIS MAP?
If no translation for this map exists in your language, and you want to translate this map, get in contact: https://ijaminecraft.com/en/contact
Do not directly translate the language files in this resource pack, as they get automatically generated. Get in contact, so I can send you the proper translation files.